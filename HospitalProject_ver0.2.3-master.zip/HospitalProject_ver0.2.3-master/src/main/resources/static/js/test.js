/**
 * 
 */
 
 /*
else if(document.joinInfo_frm.hspLunchSt.value == "시간선택"
	&& document.joinInfo_frm.hspLunchCl.value == "시간선택"){
		alert("운영시간은 필수선택사항입니다!");
		return;
	}
else if(document.joinInfo_frm.hspStMon.value == "시간선택" 
	&& document.joinInfo_frm.hspClMon.value == "시간선택"
	
	&& document.joinInfo_frm.hspStTue.value == "시간선택"
	&& document.joinInfo_frm.hspClTue.value == "시간선택"
	
	&& document.joinInfo_frm.hspStWed.value == "시간선택"
	&& document.joinInfo_frm.hspClWed.value == "시간선택"
	
	&& document.joinInfo_frm.hspStThu.value == "시간선택"
	&& document.joinInfo_frm.hspClThu.value == "시간선택"
	
	&& document.joinInfo_frm.hspStFri.value == "시간선택"
	&& document.joinInfo_frm.hspClFri.value == "시간선택"
	
	&& document.joinInfo_frm.hspStSat.value == "시간선택"
	&& document.joinInfo_frm.hspClSat.value == "시간선택"
	
	&& document.joinInfo_frm.hspStSun.value == "시간선택"
	&& document.joinInfo_frm.hspClSun.value == "시간선택"
	) {
		alert("운영시간은 필수선택사항입니다!");
		return;
	}
	*/