package com.sycompany.hsp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HspKindListDto {

	private boolean hspKindList1;
	private boolean hspKindList2;
	private boolean hspKindList3;
	private boolean hspKindList4;
	private boolean hspKindList5;
	private boolean hspKindList6;
	private boolean hspKindList7;
	private boolean hspKindList8;
	private boolean hspKindList9;
	private boolean hspKindList10;
	private boolean hspKindList11;
	private boolean hspKindList12;
	private boolean hspKindList13;
	private boolean hspKindList14;
	private boolean hspKindList15;
	
}
